document.getElementById("login-form").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent the form from submitting

    // Get the username and password input values
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;

    // You can replace this with your authentication logic
    if (username === "admin" && password === "password") {
        // Successful login
        document.getElementById("login-message").innerText = "Login successful!";
        // You can redirect the user to another page here if needed
    } else {
        // Failed login
        document.getElementById("login-message").innerText = "Invalid username or password. Please try again.";
    }
});